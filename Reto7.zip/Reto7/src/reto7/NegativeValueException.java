package reto7;

public class NegativeValueException extends Exception {

    public NegativeValueException() {
        super("negative value error. Try inputting the information correctly.");
    }

}
