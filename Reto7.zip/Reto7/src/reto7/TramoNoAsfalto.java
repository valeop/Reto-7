package reto7;

public class TramoNoAsfalto extends Tramo implements Carretera {

    private double x1, y1, x2, y2, espesor;
    private String tipoMaterial;

    public TramoNoAsfalto() {
    }

    public TramoNoAsfalto(double x1, double y1, double x2, double y2, double espesor, String tipoMaterial) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.espesor = espesor;
        this.tipoMaterial = tipoMaterial;
    }

    @Override
    public double longitud(double x1, double y1, double x2, double y2) {
        double valor = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
        return valor;
    }

    @Override
    public double area(double longitud) {
        double valor = longitud * 6;
        return valor;
    }

    @Override
    public double volumen(double area) {
        double valor = area * espesor;
        return valor;
    }

    @Override
    public void guardarLista() {
        Carretera.lista.add(new TramoNoAsfalto(x1, y1, x2, y2, espesor, tipoMaterial));
    }

    @Override
    public String toString() {
        return "*Coordenada inicial: (" + x1 + ", " + y1 + ")    Coordenada final: (" + x2 + ", " + y2 + ")    Espesor: " + espesor + "    Material: " + tipoMaterial;
    }

}
