package reto7;

import java.util.List;
import javax.swing.JOptionPane;

public class Principal {

    static String[] opciones1 = {"Asfaltado", "Sin asfalto"};
    static String[] opciones2 = {"Piedra", "Arena", "Balastro"};
    static String[] opciones3 = {"Ver lista", "Resumen", "Salir"};
    static int tramos, choice, maxSpeed, cont = 0;
    static double x1, x2, y1, y2, longitud, area, volumen, espesor, longitudTotal = 0, areaTotal = 0, volumenTotal = 0, volumenAsfalto = 0, volumenSinAsfalto = 0;
    static double antX, antY;
    static String proveedor, tipoMaterial, condicion;

    public static void main(String[] args) throws NegativeValueException, ExitException {
        tramos = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad de tramos/vías que se construirán", "SISTEMA DE CONSTRUCCIÓN DE VÍAS", JOptionPane.INFORMATION_MESSAGE));
        negativeException(tramos);
        String[] conexiones = new String[tramos - 1];
        String[] calculos = new String[tramos];
        for (int i = 0; i < tramos; i++) {
            x1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese coordenada X1 (eje x)", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE));
            y1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese coordenada Y1 (eje y)", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE));
            x2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese coordenada X2 (eje x)", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE));
            y2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese coordenada Y2 (eje y)", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE));
            choice = JOptionPane.showOptionDialog(null, "¿Qué tipo de tramo es?", "TRAMO N° " + (i + 1), JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones1, 0);
            exitException(choice);
            if (choice == 0) {
                proveedor = JOptionPane.showInputDialog(null, "Ingrese el nombre de proveedor del asfalto", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE);
                maxSpeed = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la velocidad máxima permitida en este tramo (km/h)", "TRAMO N° " + (i + 1), JOptionPane.INFORMATION_MESSAGE));
                negativeException(maxSpeed);
                choice = JOptionPane.showConfirmDialog(null, "¿Se permite que los vehículos se adelanten?", "TRAMO N° " + (i + 1), JOptionPane.YES_NO_OPTION);
                exitException(choice);
                condicion(choice);
                TramoAsfalto a = new TramoAsfalto(x1, y1, x2, y2, proveedor, maxSpeed, condicion);
                a.guardarLista();
                longitud = a.longitud(x1, y1, x2, y2);
                area = a.area(longitud);
                volumen = a.volumen(area);
                calculos[i] = " Longitud: " + longitud + " m     Área: " + area + " m^2     Volumen: " + volumen + " m^3";
                longitudTotal = Carretera.longitudTotal(longitud, longitudTotal);
                areaTotal = Carretera.areaTotal(area, areaTotal);
                volumenTotal = Carretera.volumenTotal(volumen, volumenTotal);
                volumenAsfalto = Carretera.volumenAsfalto(volumen, volumenAsfalto);
            } else if (choice == 1) {
                choice = JOptionPane.showOptionDialog(null, "Selecciona el tipo de material para el tramo", "TRAMO N° " + (i + 1), JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones2, 0);
                exitException(choice);
                tipoMaterial(choice);
                TramoNoAsfalto a = new TramoNoAsfalto(x1, y1, x2, y2, espesor, tipoMaterial);
                a.guardarLista();
                longitud = a.longitud(x1, y1, x2, y2);
                area = a.area(longitud);
                volumen = a.volumen(area);
                calculos[i] = " Longitud: " + longitud + " m     Área: " + area + " m^2     Volumen: " + volumen + " m^3";
                longitudTotal = Carretera.longitudTotal(longitud, longitudTotal);
                areaTotal = Carretera.areaTotal(area, areaTotal);
                volumenTotal = Carretera.volumenTotal(volumen, volumenTotal);
                volumenSinAsfalto = Carretera.volumenNoAsfalto(volumen, volumenSinAsfalto);
            }
            if (i != 0) {
                boolean respuesta = Carretera.conexionCarreteras(antX, antY, x1, y1);
                if (respuesta) {
                    conexiones[i - 1] = "Tramo N° " + (cont + 1) + " y el tramo N° " + (cont + 2) + " SÍ están conectados";
                } else {
                    conexiones[i - 1] = "Tramo N° " + (cont + 1) + " y el tramo N° " + (cont + 2) + " NO están conectados";
                }
                cont++;
            }
            antX = x2;
            antY = y2;
        }
        choice = 1;
        while (choice != 2) {
            choice = JOptionPane.showOptionDialog(null, "Seleccione la operación que desea", "RESULTADO", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones3, 0);
            exitException(choice);
            switch (choice) {
                case 0:
                    mostrarLista(Carretera.lista, calculos);
                    break;
                case 1:
                    mostrarInformacion(conexiones);
                    break;
                case 2:
                    System.exit(0);
                    break;
            }
        }
    }

    private static void exitException(int num) throws ExitException {
        if (num == -1) {
            throw new ExitException();
        }
    }

    private static void negativeException(int num) throws NegativeValueException {
        if (num < 0) {
            throw new NegativeValueException();
        }
    }

    private static void condicion(int eleccion) {
        switch (eleccion) {
            case 0:
                condicion = "NO";
                break;
            case 1:
                condicion = "SÍ";
                break;
        }
    }

    private static void tipoMaterial(int eleccion) {
        switch (eleccion) {
            case 0:
                tipoMaterial = "Piedra";
                espesor = 0.5;
                break;
            case 1:
                tipoMaterial = "Arena";
                espesor = 0.27;
                break;
            case 2:
                tipoMaterial = "Balastro";
                espesor = 0.35f;
                break;
        }
    }

    public static void mostrarLista(List<Tramo> lista, String[] arreglo) {
        int contador = 0;
        System.out.println("\n\n----------------------------------------  LISTA DE TRAMOS  ----------------------------------------\n");
        for (Tramo i : lista) {
            System.out.println(i);
            System.out.println(arreglo[contador] + "\n");
            contador++;
        }
        System.out.println("\n---------------------------------------------------------------------------------------------------");
    }

    public static void mostrarInformacion(String[] arreglo) {
        System.out.println("\n\n------------------------------------------  RESULTADOS  ------------------------------------------\n");
        System.out.println("CONEXIONES ENTRE VÍAS:");
        for (String i : arreglo) {
            System.out.println(i + "\n");
        }
        System.out.println("\nINFORMACIÓN DE SUMATORIAS (REDONDEO)");
        System.out.println("Longitud total de la carretera: " + Math.round(longitudTotal) + " m");
        System.out.println("Área total de la carretera: " + Math.round(areaTotal) + " m^2");
        System.out.println("Volumen total del material de carretera: " + Math.round(volumenTotal) + " m^3");
        System.out.println("Volumen total de carretera con asfalto: " + Math.round(volumenAsfalto) + " m^3");
        System.out.println("Volumen total de carretera sin asfalto: " + Math.round(volumenSinAsfalto) + " m^3");
        System.out.println("\n---------------------------------------------------------------------------------------------------");
    }

}
