package reto7;

import java.util.LinkedList;
import java.util.List;

public interface Carretera{
    public static List<Tramo> lista = new LinkedList<>();

    public void guardarLista();

    public static double longitudTotal(double longitud, double total) {
        total += longitud;
        return total;
    }

    public static double areaTotal(double area, double total) {
        total += area;
        return total;
    }

    public static double volumenTotal(double volumen, double total) {
        total += volumen;
        return total;
    }

    public static double volumenAsfalto(double volumenAsfalto, double total) {
        total += volumenAsfalto;
        return total;
    }

    public static double volumenNoAsfalto(double volumenSinAsfalto, double total) {
        total += volumenSinAsfalto;
        return total;
    }

    public static boolean conexionCarreteras(double x1, double y1, double x2, double y2) {
        boolean resultado = false;
        if (x1 == x2 && y1 == y2) {
            resultado = true;
        }
        return resultado;
    }

}
