package reto7;

public abstract class Tramo {

    public abstract double longitud(double x1, double y1, double x2, double y2);

    public abstract double area(double longitud);

    public abstract double volumen(double area);

}
