package reto7;

public class ExitException extends Exception {

    public ExitException() {
        super("you´ve exited from the compiler succesfully.");
    }

}
